package com.lms.service;

import java.util.List;

import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;

public interface IAdminService {
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered)
			throws LmsException;

	public boolean isDeleted(String programName) throws LmsException;

	public boolean isUpdated(String programName, int rate, int minAmount,
			int maxAmount, String idRequired) throws LmsException;

	public List<LoanProgramsOffered> viewAll() throws LmsException;

	public LoanProgramsOffered viewSprcific(String name) throws LmsException;
	public boolean isRateUpdated(String programName, int rate) throws LmsException;
}
