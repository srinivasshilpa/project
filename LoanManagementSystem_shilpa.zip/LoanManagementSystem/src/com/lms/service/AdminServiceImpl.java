package com.lms.service;

import java.util.List;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.dao.AdminDaoImpl;
import com.lms.dao.IAdminDao;
import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class AdminServiceImpl implements IAdminService {
	static Logger logger=Logger.getRootLogger();
	private EntityManager entityManager;
private IAdminDao adminDao;


public AdminServiceImpl() {
	
	entityManager = JPAUtil.getEntityManager();
	PropertyConfigurator.configure("resources/log4j.properties");
	
adminDao= new AdminDaoImpl();
}
	@Override
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered) throws LmsException {
		boolean isInserted=false;
		isInserted=adminDao.isLoanProgramInserted(loanProgramsOffered);
		logger.info("successful");
		return isInserted;
	}
	@Override
	public boolean isDeleted(String programName) throws LmsException {
		boolean isDeleted=false;
		isDeleted=adminDao.isDeleted(programName);
		logger.info("successful");
		return isDeleted;
	}
	@Override
	public boolean isUpdated(String programName, int rate, int minAmount,
			int maxAmount, String idRequired) throws LmsException {
		boolean isUpdated= false;
		isUpdated=adminDao.isUpdated(programName, rate, minAmount, maxAmount, idRequired);
		logger.info("successful");
		return isUpdated;
	}
	@Override
	public List<LoanProgramsOffered> viewAll() throws LmsException {
	List<LoanProgramsOffered> viewAllllLoans=null;
	viewAllllLoans=adminDao.viewAll();
	logger.info("successful");
		return viewAllllLoans;
	}
	@Override
	public LoanProgramsOffered viewSprcific(String name) throws LmsException {
		LoanProgramsOffered specificLoan=adminDao.viewSprcific(name);
		logger.info("successful");
		return specificLoan;
	}
	@Override
	public boolean isRateUpdated(String programName, int rate)
			throws LmsException {
		boolean isRateUpdated=false;
		isRateUpdated=adminDao.isRateUpdated(programName, rate);
		logger.info("successful");
		return isRateUpdated;
	}

}
