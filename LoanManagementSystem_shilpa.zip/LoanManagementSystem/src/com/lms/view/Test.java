package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.lms.entity.ApprovedLoans;
import com.lms.entity.CustomerDetails;
import com.lms.entity.LoanApplication;
import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.CustomerServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.ICustomerService;
import com.lms.service.ILadService;
import com.lms.service.IUserService;
import com.lms.service.LadServiceImpl;
import com.lms.service.UserServiceImpl;

public class Test {
	

	public static void main(String[] args) throws IOException, LmsException, ParseException {
		IUserService userservice = new UserServiceImpl();
		IAdminService adminService = new AdminServiceImpl();
		Users users = new Users();
		ICustomerService customerService = new CustomerServiceImpl();
		CustomerDetails customer = new CustomerDetails();
		ILadService lad= new LadServiceImpl();
		LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		//INSERT CUSTOMER 
		/*System.out.println("Enter Customer Details");
		customer.setApplicantName("Kunl");
		//String sDate1=br.readLine();
		Date dob=new SimpleDateFormat("dd/MM/yyyy").parse("27/06/1995");
		
		customer.setDob(dob);
		customer.setCountOfDependents(3);
		customer.setEmailId("abc@xyz.com");
		customer.setMaritalStatus("single");
		customer.setMobileNumber(Long.parseLong("8080699942"));
		customer.setPhoneNumber(Long.parseLong("2730177"));
		customerService.registerCustomer(customer);*/
		
		//INSERT LOAN APPLICATION
		/*LoanApplication loan = new LoanApplication();
		System.out.println("Enter Loan Application Details");
		
		Date dob1=new SimpleDateFormat("dd/MM/yyyy").parse("27/06/1995");
		
		loan.setApplicationDate(dob1);
		loan.setLoanProgram("car loan");
		loan.setAmountOfLoan(1000000);
		loan.setAddressOfProperty("Whitefield");
		loan.setAnnualFamilyIncome(5000000);
		loan.setDocumentProofsAvailable("Lease");
		loan.setGuranteeCover("House");
		loan.setMarketValueOfGuranteeCover(5550000);
		loan.setStatus("Unapproved");
		Date interviewdate=new SimpleDateFormat("dd/MM/yyyy").parse("28/02/2018");
		loan.setDateOfInterview(interviewdate);
		customer.setApplicationId(loan);
		customerService.applyLoan(loan);*/
		
		// TO INSERT ADMIN N LAD

		
		/* System.out.println("username"); users.setLoginId(br.readLine());
		  System.out.println("password"); users.setPassword(br.readLine());
		  System.out.println("role"); users.setRole(br.readLine()); 
		  boolean  u=userservice.addUser(users); System.out.println(u);*/
		 
		// TO CHECK VALID USER OR NOT

		
		 /*String[] credential=new String[2];
		 System.out.println("Enter username"); credential[0]=br.readLine();
		 System.out.println("enter Password"); credential[1]=br.readLine();
		  boolean isAuthentic=userservice.authenticUser(credential);
		  System.out.println(isAuthentic);*/
		 

		// TO INSERT LOAN PROGRAM OFFERED

		
		 /*System.out.println("enetr program name");
		  loanProgramOffered.setProgramName(br.readLine());
		  System.out.println("enter description");
		  loanProgramOffered.setDescription(br.readLine());
		  System.out.println("enter type");
		  loanProgramOffered.setType(br.readLine());
		  System.out.println("enter duration in years");
		  loanProgramOffered.setDurationInYears
		  (Integer.parseInt(br.readLine()));
		  System.out.println("enter min loan amount");
		  loanProgramOffered.setMinLoanAmount(Integer.parseInt(br.readLine()));
		  System.out.println("enter max loan amount");
		  loanProgramOffered.setMaxLoanAmount(Integer.parseInt(br.readLine()));
		  System.out.println("enter rate");
		  loanProgramOffered.setRateOfInterest
		  (Integer.parseInt(br.readLine()));
		  System.out.println("enter proofs");
		  loanProgramOffered.setProofsRequired(br.readLine());
		  
		 boolean
		  isInserted=adminService.isLoanProgramInserted(loanProgramOffered);
		  System.out.println(isInserted);*/
		 

		  //TO DELETE
		 /*System.out.println("Enter program name");
		  boolean isDeleted=adminService.isDeleted(br.readLine());
		  System.out.println(isDeleted);*/
		
		
		//TO UPDATE
		/*System.out.println("Enter program name that needs to be updated");
		String programName=br.readLine();
		System.out.println("Enter the revised rate of interest");
		int rate=Integer.parseInt(br.readLine());
		System.out.println("Enter the min amount to be granted");
		int minAmount= Integer.parseInt(br.readLine());
		System.out.println("Enter the max Amount");
		int maxAmount= Integer.parseInt(br.readLine());
		System.out.println("enter the id required");
		String id=br.readLine();
		boolean isUpdated=adminService.isUpdated(programName, rate, minAmount, maxAmount, id);
		System.out.println(isUpdated);*/
		
		//VIEW ALL
		/*List<LoanProgramsOffered> viewAllLoans=null;
		viewAllLoans=adminService.viewAll();
		if(viewAllLoans==null){
			System.out.println("No loan Program exist for this bank");
		}else{
			for(LoanProgramsOffered loansPrograms:viewAllLoans){
				System.out.println(loansPrograms);
			}
		}*/
		
		//VIEW SPECIFIC 
		 /*System.out.println("Enter loan program Name");
		 LoanProgramsOffered specificLoan=adminService.viewSprcific(br.readLine());
		 System.out.println(specificLoan);*/
		
		//UPDATE JUST RATE
		/*System.out.println("enter program name");
		String programName=br.readLine();
		System.out.println("enter rate");
		int rate=Integer.parseInt(br.readLine());
		boolean isRateUpdated=adminService.isRateUpdated(programName, rate);
		System.out.println(isRateUpdated);*/
		
		/*
		Date date =new SimpleDateFormat("dd/MM/yyyy").parse("16/12/2017");
		 
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, 10); // add 10 days
		 
		date = cal.getTime();
		System.out.println(date);*/
		
		//LAD REJECTED BEFORE INTERVIEW
		//System.out.println(lad.isRejected(1));
		
		//LAD SET FOR INTERVIEW DATE
		//System.out.println(lad.isInterviewDatedUpdated(2, 14));
		
		//LAD STATUS AFTER INTERVIEW
		/*System.out.println(lad.isApprovedOrRejectedAfterinterview(3, "APPROVED"));*/
		
		
		LoanApplication searchLoan = new LoanApplication();
		searchLoan = lad.findLoan(3);
		
		//LAD APPROVE LOAN
		ApprovedLoans approvedLoans = new ApprovedLoans();
		approvedLoans.setCustomerNameString("Kunal");
		approvedLoans.setAmountOfLoanGranted(100000);
		approvedLoans.setDownPayement(100);
		approvedLoans.setMonthlyInstallment(1000);
		approvedLoans.setYearsTimePeriod(10);
		approvedLoans.setRateOfInterest(3);
		approvedLoans.setTotalAmountPayable(300000);
		approvedLoans.setApprovedLoan(searchLoan);
		lad.isAdded(approvedLoans);
	}

}
