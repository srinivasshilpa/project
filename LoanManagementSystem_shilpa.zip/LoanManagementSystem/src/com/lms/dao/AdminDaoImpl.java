package com.lms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;
import com.lms.util.JPAUtil;

public class AdminDaoImpl implements IAdminDao {
	static Logger logger=Logger.getRootLogger();
	private EntityManager entityManager;

	public AdminDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isLoanProgramInserted()
	 *  - Return Type   : boolean
	 *  - Description   : To insert a loan application
	 *  - Exception     : LmsException
*********************************************************************************/
	@Override
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered)
			throws LmsException {
		boolean isInserted = false;
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(loanProgramsOffered);
			entityManager.getTransaction().commit();
			isInserted = true;
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return isInserted;
	}

	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isDeleted()
	 *  - Return Type   : boolean
	 *  - Description   : To delete a loan application
	 *  - Exception     : LmsException
*********************************************************************************/
	
	@Override
	public boolean isDeleted(String programName) throws LmsException {
		boolean isDeleted = false;
		LoanProgramsOffered loanProgramsOffered;
		loanProgramsOffered = entityManager.find(LoanProgramsOffered.class,
				programName);
		entityManager.getTransaction().begin();
		try {
			if (loanProgramsOffered == null) {
				System.out.println("Not Found");
			} else {
				entityManager.remove(loanProgramsOffered);
				isDeleted = true;
			}
		} catch (Exception e) {
			logger.error("failed ");
		
			throw new LmsException(e.getMessage());
		}
		entityManager.getTransaction().commit();
		logger.info("successful");
		return isDeleted;
	}

/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isUpdated()
	 *  - Return Type   : boolean
	 *  - Description   : To upadate a loan application
	 *  - Exception     : LmsException
*********************************************************************************/
	
	@Override
	public boolean isUpdated(String programName, int rate, int minAmount,
			int maxAmount, String idRequired) throws LmsException {
		boolean isUpdated = false;
		LoanProgramsOffered loanProgramsOffered;

		try {
			loanProgramsOffered = entityManager.find(LoanProgramsOffered.class,
					programName);
			if (loanProgramsOffered != null) {
				entityManager.getTransaction().begin();
				loanProgramsOffered.setRateOfInterest(rate);
				loanProgramsOffered.setMinLoanAmount(minAmount);
				loanProgramsOffered.setMaxLoanAmount(maxAmount);
				loanProgramsOffered.setProofsRequired(idRequired);
				entityManager.getTransaction().commit();
				isUpdated = true;

			} else {
				System.out.println("Loan program not Found");
			}
		} catch (Exception e) {

			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return isUpdated;
	}

	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : viewAll()
	 *  - Return Type   : List
	 *  - Description   : To view all the loan applications
	 *  - Exception     : LmsException
*********************************************************************************/
	
	@Override
	public List<LoanProgramsOffered> viewAll() throws LmsException {
		List<LoanProgramsOffered> allLoansList;
		try {
			TypedQuery<LoanProgramsOffered> qry = entityManager.createQuery(
					"from LoanProgramsOffered", LoanProgramsOffered.class);

			allLoansList = qry.getResultList();
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return allLoansList;
	}
	
	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : viewSpecific()
	 *  - Description   : To view  the specific loan applications
	 *  - Exception     : LmsException
*********************************************************************************/

	@Override
	public LoanProgramsOffered viewSprcific(String name) throws LmsException {

		LoanProgramsOffered specificLoan = null;
		try {
			TypedQuery<LoanProgramsOffered> qry = entityManager.createQuery(
					"from LoanProgramsOffered where programName=:nameOfLoan",
					LoanProgramsOffered.class);
			qry.setParameter("nameOfLoan", name);
			specificLoan = qry.getSingleResult();
		} catch (Exception e) {
			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return specificLoan;
	}

	
/*********************************************************************************
	 *  - Author        : LMS TEAM 
	 *  - Creation Date : Dec,2017
	 *  - Function      : isRateUpdated()
	 *  - Return Type   : boolean
	 *  - Description   : To update the rate of loan applications
	 *  - Exception     : LmsException
*********************************************************************************/
	@Override
	public boolean isRateUpdated(String programName, int rate)
			throws LmsException {
		boolean isRateUpdated = false;
		LoanProgramsOffered loanProgramsOffered;

		try {
			loanProgramsOffered = entityManager.find(LoanProgramsOffered.class,
					programName);
			if (loanProgramsOffered != null) {
				entityManager.getTransaction().begin();
				loanProgramsOffered.setRateOfInterest(rate);
				
				entityManager.getTransaction().commit();
				isRateUpdated = true;

			} else {
				System.out.println("Loan program not Found");
			}
		} catch (Exception e) {

			logger.error("failed ");
			throw new LmsException(e.getMessage());
		}
		logger.info("successful");
		return isRateUpdated;
		
	}

}
