package com.lms.exception;

public class LmsException extends Exception {
public LmsException(String message) {
	super(message);
}
}
